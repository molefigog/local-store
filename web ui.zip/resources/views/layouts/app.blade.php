@include('front.components.head')
@include('front.components.menu')
<!---Recently Played Music--->

<!---Weekly Top 15--->

<div class="container-xxl">

    @yield('content')
</div>


<hr>
</div>
</div>
</div>
<!----Footer Start---->
@include('front.components.footer')
</div>

<!----Language Selection Modal---->


<!--Main js file Style-->
@include('front.components.js')
