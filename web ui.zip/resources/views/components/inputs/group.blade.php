<div {{ $attributes->merge(['class' => 'form-group']) }}>
    {{ $slot }}
</div>