<?php

// config/sms.php

return [
    'api_key' => env('SMS_API_KEY', 'your-default-api-key'),
    'api_secret' => env('SMS_API_SECRET', 'your-default-api-secret'),
];
