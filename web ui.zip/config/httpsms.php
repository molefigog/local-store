<?php

// config/httpsms.php

return [
    'api_key' => env('HTTPSMS_API_KEY', 'your-default-api-key'),
    
];
