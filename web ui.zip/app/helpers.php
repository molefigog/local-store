<?php

// function meta_image_url($imagePath)
// {
//     if (app()->environment('local')) {
//         return asset($imagePath);
//     }

//     return url('/' . $imagePath);
// }

